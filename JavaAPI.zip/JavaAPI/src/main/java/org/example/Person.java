package org.example;

import java.util.Scanner;

public class Person {
    private int id;
    private String name;
    private String sex;
    private float salary;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.print("Please input your id: ");
        id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        System.out.print("Please input your name: ");
        name = scanner.nextLine();
        System.out.print("Please input your sex: ");
        sex = scanner.nextLine();
        System.out.print("Please input your salary: ");
        salary = scanner.nextFloat();
    }

    @Override
    public String toString() {
        return "{\n" +
                "  \"id\":" + id + ",\n" +
                "  \"name\":\"" + name + "\",\n" +
                "  \"sex\":\"" + sex + "\",\n" +
                "  \"salary\":" + salary + "\n" +
                "}"+",";
    }
}
