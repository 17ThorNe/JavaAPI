package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        int ch = 0;
        int n = 0;
        Person[] per = null;

        while (true){
            option();
            ch = scanner.nextInt();

            if(ch == 1){
                boolean api = false;
                System.out.print("\nPlease input element of person : ");
                n = scanner.nextInt();
                per = new Person[n];
                inputArray(per, n);
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.writeValue(new File("JsonAPI/person.json"), per);
                System.out.println("Your API added successfully!");
            }else if(ch == 2){
                System.out.println("Display your api data");
                displayAPI();
            }else if(ch == 3){
                appendToAPI();
            }else if(ch == 0){
                System.out.println("Your program exiting....!");
                System.exit(0);
            }else{
                System.out.println("Your option is not found!");
            }

        }

    }

    public static void option(){
        System.out.println();
        System.out.println("----------------> OPTION <------------------");
        System.out.println("[1] : -> INPUT TO API");
        System.out.println("[2] : -> SHOW API");
        System.out.println("[3] : -> APPEND API");
        System.out.println("[0] : -> EXIT PROGRAM");
        System.out.println("--------------------------------------------");
        System.out.println();
        System.out.print("Please input your option : ");
    }

    public static void inputArray(Person[] per, int n){
        for (int i = 0; i < n; i++){
            per[i] = new Person();
            System.out.println("Input detail information of person : " + (i + 1));
            per[i].input();
        }
    }

    public static void displayAPI() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File("JsonAPI/person.json");

        // Read data from JSON file and map to array of Person objects
        Person[] persons = objectMapper.readValue(file, Person[].class);

        // Display the API data
        if (persons.length > 0) {
            System.out.println("\nAPI Data:");
            for (Person person : persons) {
                System.out.println(person.toString()); // Call toString() method
            }
        } else {
            System.out.println("API is empty.");
        }
    }


    public static void appendToAPI() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File("JsonAPI/person.json");

        // Read existing data from JSON file
        List<Person> existingPersons = objectMapper.readValue(file, new TypeReference<List<Person>>() {});

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of persons to append: ");
        int numToAppend = scanner.nextInt();
        List<Person> newPersons = new ArrayList<>();

        // Input new persons to append
        for (int i = 0; i < numToAppend; i++) {
            Person person = new Person();
            System.out.println("Input detail information of person " + (i + 1) + ":");
            person.input();
            newPersons.add(person);
        }

        // Append new persons to existing data
        existingPersons.addAll(newPersons);

        // Write the updated data back to the JSON file
        objectMapper.writeValue(file, existingPersons);

        System.out.println("Data appended successfully!");
    }

}
